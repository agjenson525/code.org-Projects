var Clicks = 0;
onEvent("Continue_Button", "click", function( ) {
  Clicks = Clicks + 1;
  if (Clicks == 1) {
    setScreen("Question_2");
  } else if ((Clicks == 2)) {
    setScreen("Question_3");
  } else if ((Clicks == 3)) {
    setScreen("Question_4");
  } else if ((Clicks == 4)) {
    setScreen("Correct_Screen");
  } else {
    setScreen("Start_Screen");
  }
});
onEvent("Start_Button", "click", function( ) {
  setScreen("Question_1");
});
onEvent("Try_Again_Button", "click", function( ) {
  setScreen("Question_1");
  Clicks = 0;
});
onEvent("1.1","click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("1.3", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("2.2", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("2.3", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("3.1", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("3.3", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("4.1", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("4.3", "click", function( ) {
  setScreen("Failed_Screen");
});
onEvent("1.2", "click", function( ) {
  setScreen("Correct_Screen");
});
onEvent("2.1", "click", function( ) {
  setScreen("Correct_Screen");
});
onEvent("3.2", "click", function( ) {
  setScreen("Correct_Screen");
});
onEvent("4.2", "click", function( ) {
  setScreen("Correct_Screen");
});
