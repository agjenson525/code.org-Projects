var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["272618c1-adca-42b6-bd98-23cd19d38d4c","09e2cefe-bdea-49bb-83a6-32e2375ff15e","18d32a4a-6fcc-4430-a0ae-4dc893112e6d","284682cc-d902-4d62-897f-803c878f424f","9c6812c1-14be-43f3-84ec-771378afe85a","8f907796-f66d-4e83-bd03-7c3f2056250a","5e51455e-59ef-429f-8e25-2eead814ddad","13680cf4-dcd7-4373-989c-adb134078b12","24385116-111a-49e2-8332-88c08883f556"],"propsByKey":{"272618c1-adca-42b6-bd98-23cd19d38d4c":{"name":"f1-up","sourceUrl":null,"frameSize":{"x":174,"y":122},"frameCount":1,"looping":true,"frameDelay":12,"version":"oLGISMYVJg2UP4sokLA7fgOFJw6N3xsQ","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":174,"y":122},"rootRelativePath":"assets/272618c1-adca-42b6-bd98-23cd19d38d4c.png"},"09e2cefe-bdea-49bb-83a6-32e2375ff15e":{"name":"f1-up-2","sourceUrl":null,"frameSize":{"x":174,"y":122},"frameCount":1,"looping":true,"frameDelay":12,"version":"gD3hU0n8NxWHGwoWF.U0A3MP34iyZixd","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":174,"y":122},"rootRelativePath":"assets/09e2cefe-bdea-49bb-83a6-32e2375ff15e.png"},"18d32a4a-6fcc-4430-a0ae-4dc893112e6d":{"name":"f1-down","sourceUrl":null,"frameSize":{"x":174,"y":122},"frameCount":1,"looping":true,"frameDelay":12,"version":"XDBWZOfteNq_lXKxn89uLlC7RAbIGSsQ","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":174,"y":122},"rootRelativePath":"assets/18d32a4a-6fcc-4430-a0ae-4dc893112e6d.png"},"284682cc-d902-4d62-897f-803c878f424f":{"name":"f1-down-2","sourceUrl":null,"frameSize":{"x":174,"y":122},"frameCount":1,"looping":true,"frameDelay":12,"version":"Vb6jNxDYuYNYcjxLqCDFKbYJBvzlHncw","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":174,"y":122},"rootRelativePath":"assets/284682cc-d902-4d62-897f-803c878f424f.png"},"9c6812c1-14be-43f3-84ec-771378afe85a":{"name":"track","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"sWSMu02sLcYVFhxHtXN9NSVWAs_6LafV","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/9c6812c1-14be-43f3-84ec-771378afe85a.png"},"8f907796-f66d-4e83-bd03-7c3f2056250a":{"name":"track2","sourceUrl":"assets/v3/animations/Ry2aFDT3fAGRp7WV0lniMilMa8CXQRgGdZB0y66GLS8/8f907796-f66d-4e83-bd03-7c3f2056250a.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"3hDXfk8NtUgjB91pF6XOvCZ0UHls5U0q","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/Ry2aFDT3fAGRp7WV0lniMilMa8CXQRgGdZB0y66GLS8/8f907796-f66d-4e83-bd03-7c3f2056250a.png"},"5e51455e-59ef-429f-8e25-2eead814ddad":{"name":"track3","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"A40hNAhfxv4A0O5EOypMldRecr5yrvPc","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/5e51455e-59ef-429f-8e25-2eead814ddad.png"},"13680cf4-dcd7-4373-989c-adb134078b12":{"name":"finish","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"Rfhl5dKQ_sCLK_xQJbZuULOkoQsfWu3i","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/13680cf4-dcd7-4373-989c-adb134078b12.png"},"24385116-111a-49e2-8332-88c08883f556":{"name":"blue","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"6XbYnGdN2ZfsU0g.iwoe8O2prY7V1E47","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/24385116-111a-49e2-8332-88c08883f556.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var gameBackground = createSprite(200, 200);
gameBackground.setAnimation ("track3");
var sprite = createSprite(260, 345);
sprite.setAnimation ("f1-up");
var sprite2 = createSprite(170, 345);
sprite2.setAnimation ("f1-up-2");
var sprite3 = createSprite(213, -150);
sprite3.setAnimation ("finish");

function draw() {
  if (keyDown("up")) {
    sprite.setAnimation ("f1-up");
    sprite.y=sprite.y-0.5;
  }
    if (keyDown("insert")) {
    sprite.setAnimation ("f1-up");
    sprite.y=sprite.y-2;
  }
  if (keyDown("down")) {
    sprite.setAnimation ("f1-up");
    sprite.y=sprite.y+0.5;
  }
  drawSprites();
  
  if (keyDown("w")) {
    sprite2.setAnimation ("f1-up-2");
    sprite2.y=sprite2.y-0.5;
  }
  if (keyDown("space")) {
    sprite2.setAnimation ("f1-up-2");
    sprite2.y=sprite2.y-2;
  }
  if (keyDown("d")) {
    sprite2.setAnimation ("f1-right-2");
    sprite2.x=sprite2.x+0.5;
  }
  
  {
  if (sprite.collide(sprite3));{
    sprite.pause();
  }
  
  if (sprite2.collide(sprite3));{
    sprite2.pause();
    }
  }
  drawSprites();
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
